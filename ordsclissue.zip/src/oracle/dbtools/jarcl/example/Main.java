
package oracle.dbtools.jarcl.example;

import java.io.InputStream;
import java.io.PrintStream;
import java.nio.charset.Charset;

public class Main {

  public static void main(String[] args) throws Exception {
    LOG.append("Executed using classloader: "
        + Thread.currentThread().getContextClassLoader());
    InputStream in = Main.class.getResourceAsStream("hello.txt");
    if (in == null) {
      LOG.append("failed to find resource");
    } else {
      byte[] bytes = new byte[2048];
      in.read(bytes);
      in.close();
      LOG.append(new String(bytes, Charset.forName("UTF-8")));
    }
    holdExecution(5);
  }
 public static void holdExecution(int delayinsec)
 {
	 try {
		Thread.sleep(delayinsec * 1000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	  LOG.append("\n" + "execution slept for " + String.valueOf(delayinsec)  + " seconds");
 }
 
  private static final PrintStream LOG = System.out;
}
